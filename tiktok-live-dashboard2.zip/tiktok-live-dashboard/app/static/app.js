const avatarUrls=new Map(),avatarRequested=new Set();
const $=id=>document.getElementById(id);
async function api(path,options={}){const r=await fetch(path,options);if(!r.ok)throw new Error(await r.text());return r.json()}
function el(tag,cls,text){const n=document.createElement(tag);if(cls)n.className=cls;if(text!==undefined)n.textContent=text;return n}
function btn(text,cls,handler){const b=el('button',cls,text);b.onclick=handler;return b}
async function refresh(){try{const [users,files]=await Promise.all([api('/api/users'),api('/api/recordings')]);$('total').textContent=users.length;$('live').textContent=users.filter(u=>u.status==='recording').length;$('saved').textContent=files.length;$('profile-count').textContent=users.length;$('archive-count').textContent=files.length;const profiles=$('profiles');profiles.replaceChildren();if(!users.length)profiles.append(el('div','empty','Ingen profiler endnu. Tilføj en ovenfor.'));users.forEach(u=>{const row=el('div','profile'),main=el('div','profile-main'),avatar=el('div','avatar',(u.username||'?').slice(0,1).toUpperCase()),info=el('div','profile-info'),actions=el('div','actions');info.append(el('div','name','@'+u.username),el('div','status '+u.status,(u.enabled?'● '+u.status:'● paused')),el('div','sub',u.last_error||('Seneste kontrol: '+(u.last_check||'Afventer'))));if(u.status==='recording')actions.append(btn('● Se LIVE','secondary',()=>watchLive(u.username)));actions.append(btn(u.enabled?'Pause':'Aktivér','secondary',async()=>{await api('/api/users/'+u.username+'/toggle',{method:'POST'});refresh()}),btn('Fjern','danger',async()=>{if(confirm('Fjern @'+u.username+' fra overvågning?')){await api('/api/users/'+u.username,{method:'DELETE'});refresh()}}));const avatarImg=el('img','avatar-photo');avatarImg.alt='Profilbillede for @'+u.username;avatarImg.loading='lazy';avatarImg.hidden=true;avatar.append(avatarImg);const cached=avatarUrls.get(u.username);if(cached){avatarImg.src=cached;avatarImg.hidden=false;avatar.classList.add('has-photo')}else if(!avatarRequested.has(u.username)){avatarRequested.add(u.username);api('/api/users/'+encodeURIComponent(u.username)+'/avatar').then(data=>{if(data.url){avatarUrls.set(u.username,data.url);avatarImg.src=data.url;avatarImg.hidden=false;avatar.classList.add('has-photo')}}).catch(()=>{});}main.append(avatar,info);row.append(main,actions);profiles.append(row)});const archive=$('recordings');archive.replaceChildren();if(!files.length)archive.append(el('div','empty','Ingen optagelser endnu.'));files.forEach(f=>{const row=el('div','file'),preview=el('div','file-preview'),playIcon=el('div','play-icon','▶'),info=el('div','file-info'),actions=el('div','actions'),a=el('a','link','Download');const thumb=el('img','recording-thumb');thumb.loading='lazy';thumb.alt='Miniature af '+f.name;thumb.src='/thumbnails/'+encodeURIComponent(f.name);thumb.onerror=()=>{thumb.remove()};preview.append(thumb,playIcon);preview.title='Afspil optagelse';preview.style.cursor='pointer';preview.onclick=()=>play(f.name);a.href='/recordings/'+encodeURIComponent(f.name);info.append(el('div','name',f.name),el('div','sub',(f.bytes/1048576).toFixed(1)+' MB · '+new Date(f.modified).toLocaleString('da-DK')));actions.append(btn('▶ Afspil','secondary',()=>play(f.name)),a,btn('Slet','danger',async()=>{if(confirm('Slet '+f.name+'?')){try{await api('/api/recordings/'+encodeURIComponent(f.name),{method:'DELETE'});refresh()}catch(e){alert(e.message)}}}));row.append(preview,info,actions);archive.append(row)})}catch(e){console.error(e)}}
$('refresh-button').onclick=refresh;
$('add').onsubmit=async e=>{e.preventDefault();try{await api('/api/users',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:$('username').value})});$('username').value='';refresh()}catch(e){alert(e.message)}};refresh();setInterval(refresh,15000);

const dialog=$('player-dialog'),player=$('player'),message=$('player-message');
let hls=null;function closePlayer(){if(hls){hls.destroy();hls=null;}player.pause();player.removeAttribute('src');player.load();dialog.close()}
$('close-player').onclick=closePlayer;
dialog.addEventListener('close',()=>{player.pause();player.removeAttribute('src');player.load()});
function play(name){
  if(hls){hls.destroy();hls=null;}
  $('player-title').textContent=name;
  message.textContent='Forbereder video… Første afspilning kan tage lidt tid.';
  player.hidden=true;
  player.src='/watch/'+encodeURIComponent(name);
  dialog.showModal();
  player.onloadedmetadata=()=>{message.textContent='';player.hidden=false};
  player.onerror=()=>{message.textContent='Videoen kunne ikke afspilles. Prøv at downloade filen.';player.hidden=true};
  player.load();
}

function watchLive(name){
  $('player-title').textContent='LIVE @'+name;
  message.textContent='Forbinder til livevisning…';player.hidden=true;
  const url='/api/live/'+encodeURIComponent(name)+'/playlist.m3u8';
  dialog.showModal();
  if(hls){hls.destroy();hls=null;}
  if(window.Hls&&Hls.isSupported()){
    hls=new Hls({liveSyncDurationCount:3});
    hls.loadSource(url);hls.attachMedia(player);
    hls.on(Hls.Events.MANIFEST_PARSED,()=>{player.hidden=false;message.textContent='';player.play().catch(()=>{message.textContent='Tryk på afspil for at starte.'})});
    hls.on(Hls.Events.ERROR,(_event,data)=>{if(data.fatal)message.textContent='Livevisning afbrudt. Luk og prøv igen.'});
  }else if(player.canPlayType('application/vnd.apple.mpegurl')){
    player.src=url;player.hidden=false;player.play().catch(()=>{message.textContent='Tryk på afspil for at starte.'});
  }else message.textContent='Din browser understøtter ikke HLS-afspilning.';
}
