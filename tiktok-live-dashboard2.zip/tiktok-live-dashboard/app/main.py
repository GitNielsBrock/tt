import os, re, sqlite3, subprocess, threading, time, datetime, pathlib, secrets, urllib.request, html, urllib.parse
from fastapi import FastAPI, HTTPException, Request, Depends
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

ROOT=pathlib.Path('/data'); ROOT.mkdir(exist_ok=True)
DB=ROOT/'dashboard.sqlite3'; RECORDINGS=ROOT/'recordings'; RECORDINGS.mkdir(exist_ok=True)
PREVIEWS=ROOT/'previews'; PREVIEWS.mkdir(exist_ok=True)
LIVE=ROOT/'live'; LIVE.mkdir(exist_ok=True)
preview_lock=threading.Lock()
THUMBS=ROOT/'thumbnails'; THUMBS.mkdir(exist_ok=True)
avatar_cache={}; avatar_lock=threading.Lock()
INTERVAL=max(30,int(os.getenv('CHECK_INTERVAL','60')))
USER=os.getenv('DASHBOARD_USER','admin'); PASSWORD=os.getenv('DASHBOARD_PASSWORD','')
if not PASSWORD: raise RuntimeError('Set DASHBOARD_PASSWORD in .env')
security=HTTPBasic(); app=FastAPI(title='TikTok LIVE Recorder')
app.mount('/static', StaticFiles(directory='/app/static'),name='static')
active={}; lock=threading.Lock(); stopping=threading.Event()

def auth(c:HTTPBasicCredentials=Depends(security)):
    if not (secrets.compare_digest(c.username,USER) and secrets.compare_digest(c.password,PASSWORD)):
        raise HTTPException(401,'Invalid credentials',headers={'WWW-Authenticate':'Basic'})

def connect():
    c=sqlite3.connect(DB,timeout=20); c.row_factory=sqlite3.Row
    c.execute('PRAGMA journal_mode=WAL')
    return c

def initialize():
    with connect() as c:
        c.execute('CREATE TABLE IF NOT EXISTS users (username TEXT PRIMARY KEY, enabled INTEGER NOT NULL DEFAULT 1, status TEXT NOT NULL DEFAULT "waiting", last_check TEXT, last_error TEXT)')

def update(name,**fields):
    if not fields:return
    with connect() as c:
        c.execute('UPDATE users SET '+', '.join(f'{k}=?' for k in fields)+' WHERE username=?',(*fields.values(),name))

class Profile(BaseModel):
    username:str

def normalize(raw):
    s=raw.strip().lstrip('@').lower()
    if not re.fullmatch(r'[a-z0-9._]{2,24}',s):raise HTTPException(422,'Invalid TikTok username')
    return s

@app.get('/',response_class=HTMLResponse)
def home(_:str=Depends(auth)):
    return pathlib.Path('/app/templates/index.html').read_text()

def public_avatar(name):
    now=time.monotonic()
    with avatar_lock:
        cached=avatar_cache.get(name)
        if cached and cached[0]>now:return cached[1]
    result=None
    try:
        req=urllib.request.Request(f'https://www.tiktok.com/@{name}',headers={'User-Agent':'Mozilla/5.0 (compatible; LiveStudio/1.0)'})
        with urllib.request.urlopen(req,timeout=6) as response:
            # Limit page size; never request arbitrary URLs provided by the page.
            page=response.read(1_500_000).decode('utf-8','replace')
        match=re.search(r'<meta[^>]+property=["\']og:image["\'][^>]+content=["\']([^"\']+)',page,re.I)
        if not match:
            match=re.search(r'<meta[^>]+content=["\']([^"\']+)["\'][^>]+property=["\']og:image["\']',page,re.I)
        if match:
            candidate=html.unescape(match.group(1))
            parsed=urllib.parse.urlparse(candidate)
            host=(parsed.hostname or '').lower()
            if parsed.scheme=='https' and (host.endswith('.tiktokcdn.com') or host.endswith('.tiktok.com') or host.endswith('.tiktokcdn-us.com')):
                result=candidate
    except Exception:
        pass
    with avatar_lock:avatar_cache[name]=(now+3600,result)
    return result

@app.get('/api/users/{name}/avatar')
def avatar(name:str,_:str=Depends(auth)):
    name=normalize(name)
    with connect() as c:
        if not c.execute('SELECT 1 FROM users WHERE username=?',(name,)).fetchone():raise HTTPException(404)
    return {'url':public_avatar(name)}

@app.get('/thumbnails/{filename}')
def thumbnail(filename:str,_:str=Depends(auth)):
    source=recording_path(filename)
    with lock:
        if any(v['path']==source for v in active.values()):raise HTTPException(409,'Recording still active')
    target=THUMBS/(source.stem+'.jpg')
    if not target.is_file() or target.stat().st_mtime_ns<source.stat().st_mtime_ns:
        temp=THUMBS/(source.stem+'.partial.jpg')
        try:
            result=subprocess.run(['ffmpeg','-nostdin','-hide_banner','-loglevel','error','-y',
                '-ss','2','-i',str(source),'-frames:v','1','-vf','scale=480:-2',str(temp)],
                capture_output=True,timeout=30)
            if result.returncode!=0 or not temp.is_file() or temp.stat().st_size==0:
                raise HTTPException(422,'Thumbnail unavailable')
            temp.replace(target)
        except subprocess.TimeoutExpired:raise HTTPException(504,'Thumbnail timed out')
        finally:temp.unlink(missing_ok=True)
    return FileResponse(target,media_type='image/jpeg',headers={'Cache-Control':'private, max-age=300'})

@app.get('/api/users')
def users(_:str=Depends(auth)):
    with connect() as c:return [dict(x) for x in c.execute('SELECT * FROM users ORDER BY username')]

@app.post('/api/users')
def add(p:Profile,_:str=Depends(auth)):
    name=normalize(p.username)
    with connect() as c:
        c.execute('INSERT OR IGNORE INTO users(username) VALUES(?)',(name,))
        c.execute('UPDATE users SET enabled=1 WHERE username=?',(name,))
    return {'username':name}

@app.delete('/api/users/{name}')
def delete(name:str,_:str=Depends(auth)):
    with connect() as c:c.execute('DELETE FROM users WHERE username=?',(normalize(name),))
    return {'ok':True}

@app.post('/api/users/{name}/toggle')
def toggle(name:str,_:str=Depends(auth)):
    with connect() as c:c.execute('UPDATE users SET enabled=1-enabled WHERE username=?',(normalize(name),))
    return {'ok':True}

def files():
    return sorted(RECORDINGS.glob('*.ts'),key=lambda p:p.stat().st_mtime,reverse=True)

@app.get('/api/recordings')
def recordings(_:str=Depends(auth)):
    return [{'name':p.name,'bytes':p.stat().st_size,'modified':datetime.datetime.fromtimestamp(p.stat().st_mtime,datetime.timezone.utc).isoformat()} for p in files()]

@app.get('/recordings/{filename}')
def download(filename:str,_:str=Depends(auth)):
    if pathlib.Path(filename).name!=filename or not filename.endswith('.ts'):raise HTTPException(400)
    path=RECORDINGS/filename
    if not path.is_file():raise HTTPException(404)
    return FileResponse(path,filename=filename,media_type='video/mp2t')

def recording_path(filename):
    if pathlib.Path(filename).name != filename or not filename.endswith('.ts'):
        raise HTTPException(400, 'Invalid recording filename')
    path = RECORDINGS / filename
    if not path.is_file():
        raise HTTPException(404, 'Recording not found')
    return path

@app.get('/watch/{filename}')
def watch(filename: str, _: str = Depends(auth)):
    source = recording_path(filename)
    with lock:
        if any(v['path'] == source for v in active.values()):
            raise HTTPException(409, 'Wait until recording has finished')
    target = PREVIEWS / (source.stem + '.mp4')
    # Only one conversion at a time, to prevent concurrent duplicate ffmpeg jobs.
    with preview_lock:
        if not target.exists() or target.stat().st_mtime_ns < source.stat().st_mtime_ns:
            temp = PREVIEWS / (source.stem + '.partial.mp4')
            try:
                result = subprocess.run(
                    ['ffmpeg', '-nostdin', '-hide_banner', '-loglevel', 'error',
                     '-y', '-i', str(source), '-map', '0:v:0?', '-map', '0:a:0?',
                     '-c', 'copy', '-movflags', '+faststart', str(temp)],
                    capture_output=True, text=True, timeout=900)
                if result.returncode != 0 or not temp.is_file() or temp.stat().st_size == 0:
                    raise HTTPException(422, 'Could not prepare video: ' + result.stderr[-250:])
                temp.replace(target)
            except subprocess.TimeoutExpired:
                raise HTTPException(504, 'Video preparation timed out')
            finally:
                temp.unlink(missing_ok=True)
    return FileResponse(target, media_type='video/mp4', headers={'Cache-Control': 'private, no-store'})

@app.delete('/api/recordings/{filename}')
def remove_recording(filename:str,_:str=Depends(auth)):
    if pathlib.Path(filename).name!=filename or not filename.endswith('.ts'):raise HTTPException(400)
    path=RECORDINGS/filename
    with lock:
        if any(v['path']==path for v in active.values()):raise HTTPException(409,'Recording in progress')
    if not path.exists():raise HTTPException(404)
    path.unlink()
    (PREVIEWS / (path.stem + '.mp4')).unlink(missing_ok=True)
    (THUMBS / (path.stem + '.jpg')).unlink(missing_ok=True)
    return {'ok':True}

@app.get('/api/live/{name}/playlist.m3u8')
def live_playlist(name:str,_:str=Depends(auth)):
    name=normalize(name)
    with lock: running=name in active
    playlist=LIVE/name/'index.m3u8'
    if not running or not playlist.is_file():raise HTTPException(404,'Live preview not ready')
    return FileResponse(playlist,media_type='application/vnd.apple.mpegurl',headers={'Cache-Control':'no-store'})

@app.get('/api/live/{name}/{segment}')
def live_segment(name:str,segment:str,_:str=Depends(auth)):
    name=normalize(name)
    if not re.fullmatch(r'seg_[0-9]+\.ts',segment):raise HTTPException(400)
    with lock: running=name in active
    path=LIVE/name/segment
    if not running or not path.is_file():raise HTTPException(404)
    return FileResponse(path,media_type='video/mp2t',headers={'Cache-Control':'no-store'})

def record(name):
    stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d_%H%M%S')
    path=RECORDINGS/f'{name}_{stamp}.ts'
    live_dir=LIVE/name
    live_dir.mkdir(exist_ok=True)
    for old in live_dir.glob('*'):
        if old.is_file():old.unlink()
    stream=None; encoder=None
    try:
        # Streamlink writes MPEG-TS to stdout; FFmpeg copies it to archive and rolling HLS.
        stream=subprocess.Popen(['streamlink','--retry-open','1','--retry-streams','1',
          f'https://www.tiktok.com/@{name}/live','best','-O'],stdout=subprocess.PIPE,
          stderr=subprocess.DEVNULL)
        hls_opts='[f=hls:hls_time=4:hls_list_size=8:hls_flags=delete_segments+omit_endlist+temp_file:hls_segment_filename='+str(live_dir/'seg_%06d.ts')+']'+str(live_dir/'index.m3u8')
        tee='[f=mpegts]'+str(path)+'|'+hls_opts
        encoder=subprocess.Popen(['ffmpeg','-nostdin','-hide_banner','-loglevel','error',
          '-i','pipe:0','-map','0:v:0?','-map','0:a:0?','-c','copy','-f','tee',tee],
          stdin=stream.stdout,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        stream.stdout.close()
        with lock:active[name]={'proc':stream,'encoder':encoder,'path':path}
        # Wait until real output exists before reporting recording.
        deadline=time.monotonic()+30
        while time.monotonic()<deadline and not stopping.is_set():
            if path.exists() and path.stat().st_size>0:break
            if stream.poll() is not None or encoder.poll() is not None:break
            time.sleep(1)
        if path.exists() and path.stat().st_size>0:
            update(name,status='recording',last_error=None)
            while not stopping.is_set() and stream.poll() is None and encoder.poll() is None:
                time.sleep(1)
            update(name,status='offline',last_error=None)
        else:
            update(name,status='offline',last_error='Stream unavailable or preview could not start')
    except Exception as e:update(name,status='error',last_error=str(e)[:400])
    finally:
        for proc in (stream,encoder):
            if proc and proc.poll() is None:
                proc.terminate()
                try:proc.wait(timeout=10)
                except subprocess.TimeoutExpired:proc.kill();proc.wait()
        with lock:active.pop(name,None)
        if path.exists() and path.stat().st_size==0:path.unlink()
        for old in live_dir.glob('*'):
            if old.is_file():old.unlink()

def worker():
    while not stopping.is_set():
        with connect() as c:rows=[dict(r) for r in c.execute('SELECT username,enabled FROM users')]
        for r in rows:
            name=r['username']
            with lock:current=active.get(name)
            if not r['enabled']:
                if current:current['proc'].terminate()
                update(name,status='paused');continue
            if current:continue
            update(name,status='checking',last_check=datetime.datetime.now(datetime.timezone.utc).isoformat())
            threading.Thread(target=record,args=(name,),daemon=True).start()
        stopping.wait(INTERVAL)

@app.on_event('startup')
def start():
    initialize();threading.Thread(target=worker,daemon=True).start()

@app.on_event('shutdown')
def stop():
    stopping.set()
    with lock:
        for x in active.values():
            x['proc'].terminate()
            x['encoder'].terminate()
