# TikTok LIVE Recorder Dashboard (prototype)

A multi-profile web dashboard with automatic Streamlink recording attempts, persistent SQLite storage, and in-browser playback, live HLS preview, download/delete actions.

## Install (Ubuntu server with Docker Compose)

1. Install Docker Engine and the Docker Compose plugin.
2. Copy `.env.example` to `.env`, and replace `DASHBOARD_PASSWORD` with a strong password.
3. Run `docker compose up -d --build` in this directory.
4. The web interface listens on **127.0.0.1:8000**. To access it remotely, use an SSH tunnel (`ssh -L 8000:127.0.0.1:8000 user@your-server`) and browse `http://localhost:8000`. For public access, configure an HTTPS reverse proxy with appropriate security controls.
5. Add usernames in the web interface. Recordings are saved to `./data/recordings` as `.ts` files.

## Important limitations

- This is a prototype, not a guaranteed TikTok recording service. Streamlink TikTok compatibility can change, and TikTok may restrict streams by region, authentication, or access method. Test with a stream you are authorized to record.
- The scheduler starts an attempt for each enabled profile every `CHECK_INTERVAL` seconds when no active recording exists. Streamlink may exit when the profile is offline. A successful process launch does not prove the profile is live; status can briefly display `recording` during an attempt.
- It does not capture streams that began before a recording attempt, and can miss short streams.
- The Basic Auth login should be used behind HTTPS or an SSH tunnel, not exposed as plaintext HTTP.
- Recordings remain `.ts` for safer partial recording. Clicking **Afspil** remuxes a finished recording to a cached `.mp4` using FFmpeg, then plays it in the browser. Initial playback may take time, depending on file size. Playback depends on the source codecs being browser-compatible; remuxing does not re-encode.
- Preview MP4 files consume additional disk space in `./data/previews`. Deleting a recording also removes its cached preview.
- Disk usage is unbounded; monitor free space and manage recordings.
- Only record streams you have permission to save, and comply with platform rules and applicable laws.

## Live viewing

While a profile is recording, click **Se LIVE** in its row. The server uses FFmpeg to write the original MPEG-TS archive and a short rolling HLS playlist simultaneously. Live preview has several seconds of delay. The browser uses hls.js from jsDelivr (internet access required), or native HLS on Safari. Playlist and segment endpoints require dashboard authentication. The HLS segments are temporary and removed when recording ends.

**Caveats:** Streamlink TikTok access is not guaranteed. HLS previews require source codecs supported by the browser, and ffmpeg may fail to remux some streams. The UI has not been end-to-end tested with a real TikTok LIVE. Live previews and archived recordings consume disk space; protect the dashboard behind HTTPS or SSH.

## Opdateret brugerflade
Dashboardet har nu mørkt, responsivt design med sidebar, statuskort, profil-avatarer
(bogstavbaserede pladsholdere), LIVE-indikatorer og videokort med stiliserede
miniaturer. Faktiske TikTok-profilbilleder og videothumbnails hentes ikke.
Den eksisterende API, optagefunktion og HLS-afspiller er uændret.

## Profilbilleder og videominiaturer
- Dashboardet forsøger at hente offentligt profilbillede fra TikToks `og:image`-metadata. TikTok kan blokere eller ændre dette; i så fald vises initial-avatar. Billederne indlæses fra TikToks CDN i browseren.
- Miniaturer af færdige optagelser genereres med FFmpeg ved første visning og caches under `/data/thumbnails`. Under igangværende optagelser vises pladsholder.
- De nye funktioner er ikke integrationstestet mod TikTok.
